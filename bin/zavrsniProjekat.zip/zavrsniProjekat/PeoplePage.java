package zavrsniProjekat;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

public class PeoplePage extends BaseClass{
	
	
	//
	//
	//	 /$$$$$$$$ /$$                                               /$$             
	//	| $$_____/| $$                                              | $$             
	//	| $$      | $$  /$$$$$$  /$$$$$$/$$$$   /$$$$$$  /$$$$$$$  /$$$$$$   /$$$$$$$
	//	| $$$$$   | $$ /$$__  $$| $$_  $$_  $$ /$$__  $$| $$__  $$|_  $$_/  /$$_____/
	//	| $$__/   | $$| $$$$$$$$| $$ \ $$ \ $$| $$$$$$$$| $$  \ $$  | $$   |  $$$$$$ 
	//	| $$      | $$| $$_____/| $$ | $$ | $$| $$_____/| $$  | $$  | $$ /$$\____  $$
	//	| $$$$$$$$| $$|  $$$$$$$| $$ | $$ | $$|  $$$$$$$| $$  | $$  |  $$$$//$$$$$$$/
	//	|________/|__/ \_______/|__/ |__/ |__/ \_______/|__/  |__/   \___/ |_______/ 
	//	                                                                             
	//	                                                                             
	//	                                                                             
	//
	// -------------------------------
	//
	
	private static List <WebElement> bioList() {
		return driver.findElements(By.cssSelector("div.bio:nth-child(1) > div"));
	}
	
	
	//
	//
	//	 /$$      /$$             /$$     /$$                       /$$          
	//	| $$$    /$$$            | $$    | $$                      | $$          
	//	| $$$$  /$$$$  /$$$$$$  /$$$$$$  | $$$$$$$   /$$$$$$   /$$$$$$$  /$$$$$$$
	//	| $$ $$/$$ $$ /$$__  $$|_  $$_/  | $$__  $$ /$$__  $$ /$$__  $$ /$$_____/
	//	| $$  $$$| $$| $$$$$$$$  | $$    | $$  \ $$| $$  \ $$| $$  | $$|  $$$$$$ 
	//	| $$\  $ | $$| $$_____/  | $$ /$$| $$  | $$| $$  | $$| $$  | $$ \____  $$
	//	| $$ \/  | $$|  $$$$$$$  |  $$$$/| $$  | $$|  $$$$$$/|  $$$$$$$ /$$$$$$$/
	//	|__/     |__/ \_______/   \___/  |__/  |__/ \______/  \_______/|_______/ 
	//	                                                                         
	//	                                                                         
	//	                                                                         
	//
	// --------------------------------
	
	public void countPeople() {
		System.out.println(bioList().size());
	}
	
	public ArrayList <String> StringList() {
        ArrayList <String> imena = new ArrayList<String>();
        for (int i=0; i<bioList().size(); i++) {
            String a = bioList().get(i).findElement(By.cssSelector("b")).getText();
            String b = bioList().get(i).findElement(By.cssSelector("i")).getText();
            String c = (a + " " + b);
            imena.add(c);
        }
        
        return imena;
        
        }
        
    public void sthCrazy(ArrayList <String> imena) {
        try {
            final String FILE = "C:\\Users\\m\\Documents\\Book1.xlsx";
            FileInputStream stream = new FileInputStream(FILE);
            XSSFWorkbook wb = new XSSFWorkbook(stream);
            XSSFSheet sheet1 = wb.getSheetAt(0);        
            for (int s = 0; s<imena.size(); s++) {
                String x = (imena.get(s));
                sheet1.getRow(s+1).getCell(0).setCellValue(s+1);
                sheet1.getRow(s+1).getCell(1).setCellValue(x);
                }
            stream.close();
            FileOutputStream outputStream = new FileOutputStream(FILE);
            wb.write(outputStream);
            wb.close();
        } catch (Exception e) {
            System.out.println("woopsie");
        }
	
}
}
